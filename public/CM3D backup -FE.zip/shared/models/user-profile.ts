export interface UserProfile {
    email: string;
    firstName: string;
    lastName: string;
    password: string;
    roles?: string[];
}
