export const environment = {
  production: true,
  apiServer: 'https://cm3dapp.azurewebsites.net',
  clientId: 'bd8a697c-0795-4231-9764-8e4d1e5bcac5',
  authority: 'https://login.microsoftonline.com/1ca6df86-6785-4ffe-8dd3-b0c8527f33cc/',
  redirectUrl: 'https://cm3dapp.azurewebsites.net/'
  // apiServer: 'http://localhost:8089',
  // clientId: '6fbedafe-19cb-45e2-be2b-58f924c0eb9b',
  // authority: 'https://login.microsoftonline.com/1ca6df86-6785-4ffe-8dd3-b0c8527f33cc/',
  // redirectUrl: 'http://localhost:8089/home/'
};
